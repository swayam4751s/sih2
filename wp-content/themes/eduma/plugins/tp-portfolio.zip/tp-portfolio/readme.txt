== Changelog ==

= 1.8 =
- Fix issue remove images in type Gallery

= 1.7 =
- Fix issue remove images in type Slider

= 1.6 =
- Update translate archive portfolio url
