=== Thim Twitter ===
	Contributors: Khoapq
	Donate link: http://thimpress.com
	Tags: Twitter Feed, twitter, Thim Twitter
	Requires at least: 4.1
	Tested up to: 4.3.1
	Stable tag: 1.0
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Thim Twitter is easy to get feed on your account.




###  Thim Twitter




== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>Thim Twitter</strong>" activate it.<br />

After activate plugin you will see "Thim Twitter" menu at left side on WordPress dashboard.

** Override template file in: YourTheme/thim-twitter/



== Changelog ==


	= 1.0.0 =
    * Initial release.
